create extension if not exists "uuid-ossp";
create extension if not exists "pgsodium";

-- Profiles
create table public.profiles (
  id uuid references auth.users(id) on delete cascade primary key,
  full_name text,
  avatar_url text,
  onboarded boolean default false,
  created_at timestamptz default now()
);

-- Accounts
create table public.accounts (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  name text not null,
  category text not null check (category in (
    'cash','investment','real_estate','retirement','vehicle','crypto','other_asset',
    'mortgage','loan','credit','other_liability'
  )),
  type text not null check (type in ('asset', 'liability')),
  institution text,
  notes text,
  is_manual boolean default true,
  plaid_account_id text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Balances
create table public.balances (
  id uuid default uuid_generate_v4() primary key,
  account_id uuid references public.accounts(id) on delete cascade not null,
  user_id uuid references public.profiles(id) on delete cascade not null,
  value numeric(14,2) not null default 0,
  recorded_at timestamptz default now()
);

-- Snapshots
create table public.snapshots (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  total_assets numeric(14,2) not null,
  total_liabilities numeric(14,2) not null,
  net_worth numeric(14,2) not null,
  snapshot_date date not null,
  created_at timestamptz default now(),
  unique(user_id, snapshot_date)
);

-- Plaid items (access tokens encrypted via pgsodium/Vault)
create table public.plaid_items (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  item_id text not null unique,
  institution_name text,
  -- access_token stored as encrypted bytes; use pgsodium.crypto_aead_det_encrypt
  -- Decrypt with pgsodium.crypto_aead_det_decrypt using your Vault key_id
  access_token_encrypted bytea not null,
  key_id uuid not null,  -- references pgsodium.valid_key(id)
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- RLS
alter table public.profiles enable row level security;
alter table public.accounts enable row level security;
alter table public.balances enable row level security;
alter table public.snapshots enable row level security;
alter table public.plaid_items enable row level security;

create policy "Users can manage own profile"     on public.profiles    for all using (auth.uid() = id);
create policy "Users can manage own accounts"    on public.accounts    for all using (auth.uid() = user_id);
create policy "Users can manage own balances"    on public.balances    for all using (auth.uid() = user_id);
create policy "Users can manage own snapshots"   on public.snapshots   for all using (auth.uid() = user_id);
create policy "Users can manage own plaid items" on public.plaid_items for all using (auth.uid() = user_id);

-- Indexes for common queries
create index accounts_user_id_idx      on public.accounts(user_id);
create index balances_account_id_idx   on public.balances(account_id);
create index balances_user_id_idx      on public.balances(user_id);
create index snapshots_user_id_idx     on public.snapshots(user_id);
create index plaid_items_user_id_idx   on public.plaid_items(user_id);
create index accounts_plaid_acct_idx   on public.accounts(plaid_account_id) where plaid_account_id is not null;

-- Auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, new.raw_user_meta_data->>'full_name');
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Auto-update updated_at
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger accounts_updated_at    before update on public.accounts    for each row execute function public.set_updated_at();
create trigger plaid_items_updated_at before update on public.plaid_items for each row execute function public.set_updated_at();

-- ─────────────────────────────────────────────
-- Plaid token encryption helpers (pgsodium)
-- Run after enabling the pgsodium extension.
-- ─────────────────────────────────────────────

create or replace function public.encrypt_plaid_token(plaintext text, key_id uuid)
returns text
language plpgsql security definer
as $$
declare
  result bytea;
begin
  select pgsodium.crypto_aead_det_encrypt(
    convert_to(plaintext, 'utf8'),
    convert_to(key_id::text, 'utf8'),
    key_id
  ) into result;
  return encode(result, 'base64');
end;
$$;

create or replace function public.decrypt_plaid_token(ciphertext text, key_id uuid)
returns text
language plpgsql security definer
as $$
declare
  result bytea;
begin
  select pgsodium.crypto_aead_det_decrypt(
    decode(ciphertext, 'base64'),
    convert_to(key_id::text, 'utf8'),
    key_id
  ) into result;
  return convert_from(result, 'utf8');
end;
$$;

-- Revoke direct execution from anon/authenticated; only service role calls these
revoke execute on function public.encrypt_plaid_token from anon, authenticated;
revoke execute on function public.decrypt_plaid_token from anon, authenticated;
