import { NextRequest, NextResponse } from 'next/server'
import { Configuration, PlaidApi, PlaidEnvironments } from 'plaid'
import { createServerSupabaseClient } from '@/lib/supabase-server'
import { encryptAccessToken } from '@/lib/plaid-crypto'

const plaidClient = new PlaidApi(new Configuration({
  basePath: PlaidEnvironments[(process.env.PLAID_ENV as keyof typeof PlaidEnvironments) || 'sandbox'],
  baseOptions: {
    headers: {
      'PLAID-CLIENT-ID': process.env.PLAID_CLIENT_ID,
      'PLAID-SECRET': process.env.PLAID_SECRET,
    },
  },
}))

function mapPlaidType(type: string, subtype: string | null): string {
  if (type === 'depository') return 'cash'
  if (type === 'investment') return 'investment'
  if (type === 'loan' && subtype === 'mortgage') return 'mortgage'
  if (type === 'loan') return 'loan'
  if (type === 'credit') return 'credit'
  return 'other_asset'
}

export async function POST(req: NextRequest) {
  try {
    const { public_token, institution_name } = await req.json()

    if (!public_token) {
      return NextResponse.json({ error: 'Missing public_token' }, { status: 400 })
    }

    const supabase = await createServerSupabaseClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    // Exchange public token for access token
    const { data } = await plaidClient.itemPublicTokenExchange({ public_token })
    const access_token = data.access_token
    const item_id = data.item_id

    // Encrypt access token before storing
    const { encrypted, keyId } = await encryptAccessToken(access_token)

    await supabase.from('plaid_items').insert({
      user_id: user.id,
      item_id,
      institution_name,
      access_token_encrypted: encrypted,
      key_id: keyId,
    })

    // Fetch and store initial balances
    const balanceResponse = await plaidClient.accountsBalanceGet({ access_token })

    for (const plaidAccount of balanceResponse.data.accounts) {
      const category = mapPlaidType(plaidAccount.type, plaidAccount.subtype ?? null)
      const type = ['mortgage', 'loan', 'credit', 'other_liability'].includes(category) ? 'liability' : 'asset'

      const { data: account, error } = await supabase.from('accounts').insert({
        user_id: user.id,
        name: plaidAccount.name,
        category,
        type,
        institution: institution_name,
        is_manual: false,
        plaid_account_id: plaidAccount.account_id,
      }).select().single()

      if (!error && account) {
        await supabase.from('balances').insert({
          account_id: account.id,
          user_id: user.id,
          value: plaidAccount.balances.current ?? 0,
        })
      }
    }

    return NextResponse.json({ success: true })
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Unknown error'
    console.error('Plaid exchange token error:', message)
    return NextResponse.json({ error: 'Failed to connect bank account' }, { status: 500 })
  }
}
