import { NextRequest, NextResponse } from 'next/server'
import { Configuration, PlaidApi, PlaidEnvironments } from 'plaid'
import { createServerSupabaseClient } from '@/lib/supabase-server'
import { decryptAccessToken } from '@/lib/plaid-crypto'

const plaidClient = new PlaidApi(new Configuration({
  basePath: PlaidEnvironments[(process.env.PLAID_ENV as keyof typeof PlaidEnvironments) || 'sandbox'],
  baseOptions: {
    headers: {
      'PLAID-CLIENT-ID': process.env.PLAID_CLIENT_ID,
      'PLAID-SECRET': process.env.PLAID_SECRET,
    },
  },
}))

export async function POST(req: NextRequest) {
  try {
    const supabase = await createServerSupabaseClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { data: items } = await supabase
      .from('plaid_items')
      .select('*')
      .eq('user_id', user.id)

    if (!items?.length) return NextResponse.json({ updated: 0 })

    let updated = 0
    const errors: string[] = []

    for (const item of items) {
      try {
        // Decrypt access token
        const access_token = await decryptAccessToken(item.access_token_encrypted, item.key_id)
        const { data: balanceData } = await plaidClient.accountsBalanceGet({ access_token })

        for (const plaidAccount of balanceData.accounts) {
          const { data: account } = await supabase
            .from('accounts')
            .select('id')
            .eq('plaid_account_id', plaidAccount.account_id)
            .eq('user_id', user.id)
            .single()

          if (account) {
            await supabase.from('balances').insert({
              account_id: account.id,
              user_id: user.id,
              value: plaidAccount.balances.current ?? 0,
            })
            updated++
          }
        }
      } catch (itemError: unknown) {
        const msg = itemError instanceof Error ? itemError.message : 'Unknown error'
        errors.push(`Item ${item.item_id}: ${msg}`)
        console.error('Sync error for item', item.item_id, msg)
      }
    }

    return NextResponse.json({ updated, ...(errors.length ? { errors } : {}) })
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Unknown error'
    console.error('Plaid sync error:', message)
    return NextResponse.json({ error: 'Sync failed' }, { status: 500 })
  }
}
