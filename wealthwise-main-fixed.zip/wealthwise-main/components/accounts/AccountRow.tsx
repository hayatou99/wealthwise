'use client'
import { useState } from 'react'
import { AccountWithBalance, CATEGORY_META } from '@/types'
import { formatCurrency } from '@/lib/utils'
import { deleteAccount, updateBalance } from '@/lib/db'
import { useWealthStore } from '@/store/wealth'

export default function AccountRow({ account }: { account: AccountWithBalance }) {
  const { removeAccount, setAccounts, accounts } = useWealthStore(s => ({
    removeAccount: s.removeAccount,
    setAccounts: s.setAccounts,
    accounts: s.accounts,
  }))
  const [deleting, setDeleting] = useState(false)
  const [editing, setEditing] = useState(false)
  const [editValue, setEditValue] = useState(String(account.balance))
  const [saving, setSaving] = useState(false)
  const [editError, setEditError] = useState('')
  const meta = CATEGORY_META[account.category]

  async function handleDelete() {
    if (!confirm(`Remove "${account.name}"?`)) return
    setDeleting(true)
    await deleteAccount(account.id)
    removeAccount(account.id)
  }

  async function handleSaveBalance() {
    const num = parseFloat(editValue)
    if (isNaN(num) || num < 0) { setEditError('Enter a valid amount'); return }
    setSaving(true)
    setEditError('')
    await updateBalance(account.id, account.user_id, num)
    // Update local state without a reload
    setAccounts(accounts.map(a => a.id === account.id ? { ...a, balance: num, recorded_at: new Date().toISOString() } : a))
    setEditing(false)
    setSaving(false)
  }

  function handleEditKeyDown(e: React.KeyboardEvent) {
    if (e.key === 'Enter') handleSaveBalance()
    if (e.key === 'Escape') { setEditing(false); setEditValue(String(account.balance)) }
  }

  return (
    <div className={`flex items-center gap-3 py-3 border-b border-gray-50 dark:border-gray-800 last:border-0 ${deleting ? 'opacity-40' : ''}`}>
      <div className="w-8 h-8 rounded-xl flex items-center justify-center text-base flex-shrink-0" style={{ background: meta.bg }}>
        {meta.icon}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-gray-900 dark:text-white truncate">{account.name}</p>
        <p className="text-xs text-gray-400">{meta.label}{account.institution ? ` · ${account.institution}` : ''}</p>
      </div>

      {editing ? (
        <div className="flex items-center gap-1.5">
          <div className="relative">
            <span className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-400 text-xs">$</span>
            <input
              type="number"
              min="0"
              value={editValue}
              onChange={e => setEditValue(e.target.value)}
              onKeyDown={handleEditKeyDown}
              autoFocus
              className="w-28 pl-5 pr-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-gray-900"
            />
          </div>
          {editError && <span className="text-xs text-red-500">{editError}</span>}
          <button
            onClick={handleSaveBalance}
            disabled={saving}
            className="text-xs font-medium text-emerald-600 hover:text-emerald-700 disabled:opacity-50"
          >
            {saving ? '…' : 'Save'}
          </button>
          <button
            onClick={() => { setEditing(false); setEditValue(String(account.balance)); setEditError('') }}
            className="text-xs text-gray-400 hover:text-gray-600"
          >
            Cancel
          </button>
        </div>
      ) : (
        <>
          <button
            onClick={() => { setEditing(true); setEditValue(String(account.balance)) }}
            className="text-sm font-semibold text-gray-900 dark:text-white hover:text-emerald-600 transition-colors"
            title="Click to update balance"
          >
            {formatCurrency(account.balance)}
          </button>
          <button
            onClick={handleDelete}
            disabled={deleting}
            className="w-7 h-7 flex items-center justify-center rounded-lg text-gray-300 hover:text-red-400 hover:bg-red-50 transition-all"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </>
      )}
    </div>
  )
}
