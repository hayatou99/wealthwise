'use client'
import { useState, useCallback } from 'react'
import { usePlaidLink } from 'react-plaid-link'
import { Button } from '@/components/ui'
import { useWealthStore } from '@/store/wealth'
import { getAccountsWithBalances } from '@/lib/db'

interface Props { userId: string }

export default function ConnectBankButton({ userId }: Props) {
  const setAccounts = useWealthStore(s => s.setAccounts)
  const [linkToken, setLinkToken] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function getLinkToken() {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch('/api/plaid/create-link-token', { method: 'POST' })
      const data = await res.json()
      if (!res.ok || !data.link_token) {
        setError('Could not connect to your bank. Please try again.')
        return
      }
      setLinkToken(data.link_token)
    } catch {
      setError('Network error. Please check your connection and try again.')
    } finally {
      setLoading(false)
    }
  }

  const onSuccess = useCallback(async (public_token: string, metadata: any) => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch('/api/plaid/exchange-token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          public_token,
          institution_name: metadata.institution?.name,
          accounts: metadata.accounts,
        }),
      })
      const data = await res.json()
      if (!res.ok) {
        setError(data.error || 'Failed to link bank account. Please try again.')
        return
      }
      // Refresh accounts in state — no page reload needed
      const updated = await getAccountsWithBalances(userId)
      setAccounts(updated)
      setLinkToken(null)
    } catch {
      setError('Something went wrong linking your account. Please try again.')
    } finally {
      setLoading(false)
    }
  }, [userId, setAccounts])

  const onExit = useCallback(() => {
    setLinkToken(null)
    setLoading(false)
  }, [])

  const { open, ready } = usePlaidLink({
    token: linkToken,
    onSuccess,
    onExit,
  })

  // Auto-open Plaid Link once token is ready
  if (linkToken && ready) {
    open()
  }

  return (
    <div className="flex flex-col items-end gap-1">
      <Button variant="secondary" size="sm" loading={loading} onClick={getLinkToken}>
        🏦 Connect bank
      </Button>
      {error && (
        <p className="text-xs text-red-500 max-w-[200px] text-right">{error}</p>
      )}
    </div>
  )
}
