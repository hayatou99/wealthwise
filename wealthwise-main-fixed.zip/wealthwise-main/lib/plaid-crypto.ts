/**
 * Plaid access token encryption using Supabase pgsodium Vault.
 *
 * Access tokens are encrypted/decrypted server-side via a Postgres RPC call
 * so the plaintext never touches application memory at rest.
 *
 * Setup (run once in Supabase SQL editor):
 *   select pgsodium.create_key(name := 'plaid_tokens');
 *   -- note the returned id and set it as PLAID_VAULT_KEY_ID in your env
 */

import { createServerSupabaseClient } from './supabase-server'

/**
 * Encrypts a Plaid access token using pgsodium via a Supabase RPC call.
 * Returns { encrypted, keyId } to store in plaid_items.
 */
export async function encryptAccessToken(accessToken: string): Promise<{ encrypted: string; keyId: string }> {
  const keyId = process.env.PLAID_VAULT_KEY_ID
  if (!keyId) throw new Error('PLAID_VAULT_KEY_ID env var is not set')

  const supabase = await createServerSupabaseClient()
  const { data, error } = await supabase.rpc('encrypt_plaid_token', {
    plaintext: accessToken,
    key_id: keyId,
  })
  if (error) throw new Error(`Token encryption failed: ${error.message}`)
  return { encrypted: data, keyId }
}

/**
 * Decrypts a stored Plaid access token.
 */
export async function decryptAccessToken(encrypted: string, keyId: string): Promise<string> {
  const supabase = await createServerSupabaseClient()
  const { data, error } = await supabase.rpc('decrypt_plaid_token', {
    ciphertext: encrypted,
    key_id: keyId,
  })
  if (error) throw new Error(`Token decryption failed: ${error.message}`)
  return data
}
